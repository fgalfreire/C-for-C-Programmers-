#include <iostream>
#include <queue>

#include "Graph.hpp"

typedef std::pair<int, int> aPair;

const int INF = 0x3f3f3f3f;

class Prim
{
public:
   Prim( Graph& aGraph, const int aSrc );
   //~Prim();
};
